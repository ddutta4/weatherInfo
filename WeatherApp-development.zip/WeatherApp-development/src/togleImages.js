function changeImages(weather) {
  const mainImage = document.getElementById('main-image');
  if (weather === 'Haze') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }
  if (weather === 'Clouds') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }

  if (weather === 'Rain') {
    mainImage.src = './img/animated/rainy-2.svg';
  }

  if (weather === 'Clear') {
    mainImage.src = './img/animated/day.svg';
  }

  if (weather === 'Snow') {
    mainImage.src = './img/animated/snowy-4.svg';
  }
}

function togleimagesDay1(weather) {
  const mainImage = document.getElementById('image-day1');
  if (weather === 'Haze') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }
  if (weather === 'Clouds') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }

  if (weather === 'Rain') {
    mainImage.src = './img/animated/rainy-2.svg';
  }

  if (weather === 'Clear') {
    mainImage.src = './img/animated/day.svg';
  }

  if (weather === 'Snow') {
    mainImage.src = './img/animated/snowy-4.svg';
  }
}

function togleimagesDay2(weather) {
  const mainImage = document.getElementById('image-day2');
  if (weather === 'Haze') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }
  if (weather === 'Clouds') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }

  if (weather === 'Rain') {
    mainImage.src = './img/animated/rainy-2.svg';
  }

  if (weather === 'Clear') {
    mainImage.src = './img/animated/day.svg';
  }

  if (weather === 'Snow') {
    mainImage.src = './img/animated/snowy-4.svg';
  }
}

function togleimagesDay3(weather) {
  const mainImage = document.getElementById('image-day3');
  if (weather === 'Haze') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }
  if (weather === 'Clouds') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }

  if (weather === 'Rain') {
    mainImage.src = './img/animated/rainy-2.svg';
  }

  if (weather === 'Clear') {
    mainImage.src = './img/animated/day.svg';
  }

  if (weather === 'Snow') {
    mainImage.src = './img/animated/snowy-4.svg';
  }
}

function togleimagesDay4(weather) {
  const mainImage = document.getElementById('image-day4');
  if (weather === 'Haze') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }
  if (weather === 'Clouds') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }

  if (weather === 'Rain') {
    mainImage.src = './img/animated/rainy-2.svg';
  }

  if (weather === 'Clear') {
    mainImage.src = './img/animated/day.svg';
  }

  if (weather === 'Snow') {
    mainImage.src = './img/animated/snowy-4.svg';
  }
}

function togleimagesDay5(weather) {
  const mainImage = document.getElementById('image-day5');
  if (weather === 'Haze') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }
  if (weather === 'Clouds') {
    mainImage.src = './img/animated/cloudy-day-1.svg';
  }

  if (weather === 'Rain') {
    mainImage.src = './img/animated/rainy-2.svg';
  }

  if (weather === 'Clear') {
    mainImage.src = './img/animated/day.svg';
  }

  if (weather === 'Snow') {
    mainImage.src = './img/animated/snowy-4.svg';
  }
}
export {
  changeImages,
  togleimagesDay1,
  togleimagesDay2,
  togleimagesDay3,
  togleimagesDay4,
  togleimagesDay5,
};
